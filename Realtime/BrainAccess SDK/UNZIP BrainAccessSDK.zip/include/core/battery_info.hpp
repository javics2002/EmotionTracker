/**
 * @file battery_info.hpp
 * @author Neurotechnology (brainaccess@neurotechnology.com)
 * @brief Battery info
 *
 * @copyright Copyright (c) 2022 Neurotechnology
 */

#pragma once

#include "battery_info.h"

namespace brainaccess::core
{
    typedef ba_battery_info battery_info;
}
