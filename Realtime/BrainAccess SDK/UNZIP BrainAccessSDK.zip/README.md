# SETUP

bacore.json is required in the root directory

## Connect

- model_path in the bacore.json has to be set to the models (.pt files) directory
