/**
 * @file annotation.hpp
 * @author Neurotechnology (brainaccess@neurotechnology.com)
 * @brief Annotation
 *
 * @copyright Copyright (c) 2022 Neurotechnology
 */

#pragma once

#include "annotation.h"

namespace brainaccess::core
{
	typedef ba_annotation annotation;
}
