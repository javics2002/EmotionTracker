from brainaccess.libload import load_library

_dll = load_library("babciconnect")
