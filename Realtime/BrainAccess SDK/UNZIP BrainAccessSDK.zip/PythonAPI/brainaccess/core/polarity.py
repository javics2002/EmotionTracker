import enum

class Polarity(enum.Enum):
	NONE = 0
	BOTH = 1
	POSITIVE = 2
	NEGATIVE = 3
