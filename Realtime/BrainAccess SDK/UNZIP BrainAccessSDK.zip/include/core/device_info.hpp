/**
 * @file device_info.hpp
 * @author Neurotechnology (brainaccess@neurotechnology.com)
 * @brief BrainAccess device info
 *
 * @copyright Copyright (c) 2022 Neurotechnology
 */

#pragma once

#include "device_info.h"

namespace brainaccess::core
{
	typedef ba_device_info device_info;
}
