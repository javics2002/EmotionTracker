/**
 * @file callbacks.hpp
 * @author Neurotechnology (brainaccess@neurotechnology.com)
 * @brief Callback function typedefs
 *
 * @copyright Copyright (c) 2022 Neurotechnology
 */

#pragma once

#include "callbacks.h"

namespace brainaccess::core
{
	/*TODO:
	typedef ba_callback_chunk callback_chunk;
	typedef ba_callback_battery callback_battery;
	typedef ba_callback_disconnect callback_disconnect;

	typedef ba_callback_future_void callback_future_void;
	typedef ba_callback_future_bool callback_future_bool;
	typedef ba_callback_future_float callback_future_float;
	typedef ba_callback_future_full_battery_info callback_future_full_battery_info;
	*/
}
