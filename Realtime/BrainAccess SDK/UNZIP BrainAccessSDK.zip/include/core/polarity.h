#pragma once

#include <stdint.h>

typedef uint8_t ba_polarity;

#define BA_POLARITY_NONE 0
#define BA_POLARITY_BOTH 1
#define BA_POLARITY_POSITIVE 2
#define BA_POLARITY_NEGATIVE 3
