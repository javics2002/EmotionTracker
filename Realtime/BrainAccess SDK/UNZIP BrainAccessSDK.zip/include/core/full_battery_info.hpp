/**
 * @file full_battery_info.hpp
 * @author Neurotechnology (brainaccess@neurotechnology.com)
 * @brief Full battery info
 *
 * @copyright Copyright (c) 2022 Neurotechnology
 */

#pragma once

#include "full_battery_info.h"

namespace brainaccess::core
{
    typedef ba_full_battery_info full_battery_info;
}
