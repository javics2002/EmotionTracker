#pragma once

#include "polarity.h"

namespace brainaccess::core
{
	enum class polarity : ba_polarity
	{
		NONE = BA_POLARITY_NONE,
		BOTH = BA_POLARITY_BOTH,
		POSITIVE = BA_POLARITY_POSITIVE,
		NEGATIVE = BA_POLARITY_NEGATIVE
	};
}
