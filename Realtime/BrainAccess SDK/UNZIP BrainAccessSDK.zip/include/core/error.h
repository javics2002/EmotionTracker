/**
 * @file error.h
 * @author Neurotechnology (brainaccess@neurotechnology.com)
 * @brief Error codes
 * 
 * @copyright Copyright (c) 2022 Neurotechnology
 */

#pragma once

#include <stdint.h>

#define BA_ERROR_OK 0
#define BA_ERROR_CONNECTION 1
#define BA_ERROR_UNSUPPORTED_DEVICE 2
#define BA_ERROR_UNKNOWN 0xFF

typedef uint8_t ba_error;
