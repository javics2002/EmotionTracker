#pragma once

#ifdef __cplusplus
	#define NOEXCEPT noexcept
#else
	#define NOEXCEPT
#endif
