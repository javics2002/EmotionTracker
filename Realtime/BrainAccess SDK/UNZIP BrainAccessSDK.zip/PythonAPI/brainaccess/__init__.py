"""Top-level package for brainaccess."""

__author__ = """neurotechnology"""
__email__ = 'support@neurotechnology.com'
__version__ = '2.3.0'

import brainaccess.core
